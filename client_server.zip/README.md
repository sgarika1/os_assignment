\# Java Date Server Project



This project demonstrates a client-server application using Java sockets.



\- Server sends the current date and time to the client.

\- Client connects to server and prints the date received.



\*\*Note:\*\* Initially tested on localhost (127.0.0.1). LAN testing with partner will be done separately.



